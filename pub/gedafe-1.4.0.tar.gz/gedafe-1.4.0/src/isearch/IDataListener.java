public interface IDataListener{
    
    public void newData(String data);

    public void progress(int progress);

}
